import { Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider } from "@/context/AuthContext";
import ProtectedRoute from "@/components/ProtectedRoute";
import Navbar from "@/components/Navbar";
import Login from "@/pages/Login";
import Ratings from "@/pages/Ratings";
import Upload from "@/pages/Upload";
import Audits from "@/pages/Audits";
import Reports from "@/pages/Reports";
export default function App() {
  return (
    <AuthProvider>
      <Navbar />
      <Routes>
        <Route path="/" element={<Navigate to="/ratings" />} />
        <Route path="/login" element={<Login />} />
        <Route path="/ratings" element={<ProtectedRoute><Ratings /></ProtectedRoute>} />
        <Route path="/upload" element={<ProtectedRoute><Upload /></ProtectedRoute>} />
        <Route path="/audits" element={<ProtectedRoute><Audits /></ProtectedRoute>} />
        <Route path="/reports" element={<ProtectedRoute><Reports /></ProtectedRoute>} />
        <Route path="*" element={<div className="p-6">404</div>} />
      </Routes>
    </AuthProvider>
  );
}