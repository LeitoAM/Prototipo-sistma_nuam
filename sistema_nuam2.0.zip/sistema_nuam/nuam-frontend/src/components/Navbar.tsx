import { Link, NavLink } from "react-router-dom";
import { useAuth } from "@/context/AuthContext";
export default function Navbar() {
  const { user, logout } = useAuth();
  return (
    <nav className="sticky top-0 z-10 bg-white/90 backdrop-blur border-b">
      <div className="max-w-6xl mx-auto px-4 h-14 flex items-center justify-between">
        <Link to="/" className="font-semibold text-slate-800">NUAM</Link>
        {user && (
          <div className="flex gap-4 items-center">
            <NavLink to="/ratings" className="hover:text-sky-600">Calificaciones</NavLink>
            <NavLink to="/upload" className="hover:text-sky-600">Carga CSV</NavLink>
            <NavLink to="/audits" className="hover:text-sky-600">Auditoría</NavLink>
            <NavLink to="/reports" className="hover:text-sky-600">Reportes</NavLink>
            <span className="text-sm text-slate-500">({user.username} • {user.role})</span>
            <button className="btn" onClick={logout}>Salir</button>
          </div>
        )}
      </div>
    </nav>
  );
}