import React, { createContext, useContext, useEffect, useState } from "react";
import api from "@/lib/api";
type User = { id: number; username: string; role: string } | null;
type AuthCtx = { user: User; login: (u: string, p: string) => Promise<void>; logout: () => void; };
const Ctx = createContext<AuthCtx | null>(null);
export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User>(null);
  useEffect(() => {
    const token = localStorage.getItem("token");
    if (token) api.get("/api/auth/profile/").then(r => setUser(r.data)).catch(() => setUser(null));
  }, []);
  const login = async (username: string, password: string) => {
    const res = await api.post("/api/auth/login/", { username, password });
    const token = res.data?.access;
    if (!token) throw new Error("Sin token");
    localStorage.setItem("token", token);
    const me = await api.get("/api/auth/profile/");
    setUser(me.data);
  };
  const logout = () => { localStorage.removeItem("token"); setUser(null); };
  return <Ctx.Provider value={{ user, login, logout }}>{children}</Ctx.Provider>;
};
export const useAuth = () => { const ctx = useContext(Ctx); if (!ctx) throw new Error("useAuth inside provider"); return ctx; };