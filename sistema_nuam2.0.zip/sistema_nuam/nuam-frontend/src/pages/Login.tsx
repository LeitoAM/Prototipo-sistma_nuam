import { useAuth } from "@/context/AuthContext";
import { useForm } from "react-hook-form";
import { useNavigate } from "react-router-dom";
import { useState } from "react";
type Form = { username: string; password: string };
export default function Login() {
  const { login } = useAuth();
  const { register, handleSubmit } = useForm<Form>();
  const [error, setError] = useState<string | null>(null);
  const navigate = useNavigate();
  const onSubmit = async (data: Form) => {
    setError(null);
    try { await login(data.username, data.password); navigate("/ratings"); }
    catch (e: any) { setError(e?.response?.data?.message || "Usuario o contraseña incorrecta"); }
  };
  return (
    <div className="min-h-[80vh] grid place-items-center">
      <form onSubmit={handleSubmit(onSubmit)} className="card w-full max-w-md space-y-4">
        <div><h1 className="text-2xl font-semibold">Ingresar</h1>
          <p className="text-sm text-slate-500">Accede con tus credenciales</p></div>
        {error && <div className="text-red-600 text-sm">{error}</div>}
        <div><label className="block text-sm mb-1">Usuario</label>
          <input className="w-full border rounded-xl px-3 py-2" {...register("username")} /></div>
        <div><label className="block text-sm mb-1">Contraseña</label>
          <input type="password" className="w-full border rounded-xl px-3 py-2" {...register("password")} /></div>
        <button className="btn border-sky-600 text-sky-700">Entrar</button>
      </form>
    </div>
  );
}