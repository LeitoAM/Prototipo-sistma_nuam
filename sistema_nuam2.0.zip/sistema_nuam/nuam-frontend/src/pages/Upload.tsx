import api from "@/lib/api";
import { useState } from "react";
export default function Upload() {
  const [file, setFile] = useState<File | null>(null);
  const [message, setMessage] = useState<string>("");
  const [details, setDetails] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const submit = async () => {
    if (!file) { setMessage("Selecciona un archivo .csv"); return; }
    setLoading(true); setMessage(""); setDetails(null);
    try {
      const form = new FormData();
      form.append("file", file);
      const res = await api.post("/api/ratings/upload/", form, { headers: { "Content-Type": "multipart/form-data" } });
      setMessage(res.data?.message || "Carga completa"); setDetails(res.data);
    } catch (e: any) { setMessage(e?.response?.data?.message || "Error en la carga"); }
    finally { setLoading(false); }
  };
  return (
    <div className="max-w-3xl mx-auto p-4 space-y-4">
      <div className="card space-y-3">
        <h2 className="text-lg font-semibold">Cargar calificaciones (CSV)</h2>
        <input type="file" accept=".csv" onChange={e => setFile(e.target.files?.[0] || null)} />
        <button className="btn border-sky-600 text-sky-700" onClick={submit} disabled={loading}>
          {loading ? "Subiendo..." : "Subir archivo"}
        </button>
        {message && <div className="text-sm">{message}</div>}
        {details && <pre className="bg-slate-50 p-3 rounded-xl text-xs overflow-auto">{JSON.stringify(details, null, 2)}</pre>}
      </div>
    </div>
  );
}