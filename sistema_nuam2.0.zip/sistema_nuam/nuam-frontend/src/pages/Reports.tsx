import api from "@/lib/api";
import { useEffect, useState } from "react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";
export default function Reports() {
  const [byEstado, setByEstado] = useState<any[]>([]);
  const [byPeriodo, setByPeriodo] = useState<any[]>([]);
  useEffect(() => { api.get("/api/reports/generate/").then(res => {
    setByEstado(res.data.by_estado || []); setByPeriodo(res.data.by_periodo || []);
  }); }, []);
  return (
    <div className="max-w-6xl mx-auto p-4 space-y-6">
      <div className="grid md:grid-cols-2 gap-6">
        <div className="card">
          <h3 className="font-semibold mb-3">Por estado</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={byEstado}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="estado" /><YAxis allowDecimals={false} /><Tooltip />
                <Bar dataKey="total" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
        <div className="card">
          <h3 className="font-semibold mb-3">Por periodo</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={byPeriodo}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="periodo" /><YAxis allowDecimals={false} /><Tooltip />
                <Bar dataKey="total" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
}