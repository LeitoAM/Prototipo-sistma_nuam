import api from "@/lib/api";
import { useEffect, useState } from "react";
type Item = { model: string; id: number; actor: string | null; date: string; type: string; cliente?: string; estado?: string; };
export default function Audits() {
  const [items, setItems] = useState<Item[]>([]);
  const [loading, setLoading] = useState(false);
  useEffect(() => { setLoading(true); api.get("/api/audits/").then(res => setItems(res.data)).finally(() => setLoading(false)); }, []);
  return (
    <div className="max-w-6xl mx-auto p-4 space-y-4">
      <div className="card">
        <h2 className="text-lg font-semibold mb-2">Auditoría (últimos eventos)</h2>
        {loading && <p className="text-sm text-slate-500">Cargando...</p>}
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead><tr className="text-left text-slate-500">
              <th className="py-2">Fecha</th><th>Modelo</th><th>ID</th><th>Actor</th><th>Tipo</th><th>Detalle</th></tr></thead>
            <tbody>
              {items.map((it, idx) => (
                <tr key={idx} className="border-t">
                  <td className="py-2">{new Date(it.date).toLocaleString()}</td>
                  <td>{it.model}</td><td>{it.id}</td><td>{it.actor || "-"}</td><td>{it.type}</td>
                  <td>{it.cliente ? `${it.cliente} • ${it.estado}` : "-"}</td>
                </tr>
              ))}
              {items.length === 0 && (<tr><td className="py-4 text-slate-400" colSpan={6}>Sin eventos</td></tr>)}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}