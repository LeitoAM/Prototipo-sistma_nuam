const API_URL = "http://127.0.0.1:8000"; // cambia a tu IP pública si corresponde
const api = axios.create({ baseURL: API_URL });
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});
function setStatus(text, ok=false){
  const badge = document.getElementById('statusBadge');
  badge.textContent = text;
  badge.className = 'badge ' + (ok ? 'text-bg-success' : 'text-bg-secondary');
}
async function login(){
  const username = document.getElementById('username').value.trim();
  const password = document.getElementById('password').value.trim();
  const out = document.getElementById('loginOut');
  try{
    const res = await api.post('/api/auth/login/', { username, password });
    localStorage.setItem('token', res.data.access);
    setStatus('Autenticado', true);
    out.textContent = JSON.stringify(res.data, null, 2);
  }catch(err){
    out.textContent = JSON.stringify(err.response?.data || {error: err.message}, null, 2);
    setStatus('Sin sesión', false);
  }
}
function logout(){ localStorage.removeItem('token'); setStatus('Sin sesión', false); }
async function searchRatings(){
  const out = document.getElementById('ratingsOut');
  const tbody = document.getElementById('ratingsTbody');
  tbody.innerHTML = '';
  const params = {
    cliente: document.getElementById('f_cliente').value.trim() || undefined,
    tipo: document.getElementById('f_tipo').value.trim() || undefined,
    periodo: document.getElementById('f_periodo').value.trim() || undefined,
    estado: document.getElementById('f_estado').value || undefined,
    fuente: document.getElementById('f_fuente').value.trim() || undefined,
  };
  try{
    const res = await api.get('/api/ratings/', { params });
    out.textContent = JSON.stringify(res.data, null, 2);
    const rows = res.data.results || res.data || [];
    rows.forEach(r => {
      const tr = document.createElement('tr');
      tr.innerHTML = `<td>${r.cliente||''}</td>
        <td>${r.tipo||''}</td>
        <td>${r.periodo||''}</td>
        <td>${r.estado||''}</td>
        <td>${r.fuente||''}</td>
        <td>${r.created_at ? new Date(r.created_at).toLocaleString() : ''}</td>`;
      tbody.appendChild(tr);
    });
  }catch(err){
    out.textContent = JSON.stringify(err.response?.data || {error: err.message}, null, 2);
  }
}
async function uploadCSV(){
  const fileInput = document.getElementById('csvFile');
  const out = document.getElementById('uploadOut');
  if(!fileInput.files.length){ out.textContent = 'Selecciona un archivo .csv'; return; }
  const form = new FormData();
  form.append('file', fileInput.files[0]);
  try{
    const res = await api.post('/api/ratings/upload/', form, { headers: { 'Content-Type': 'multipart/form-data' } });
    out.textContent = JSON.stringify(res.data, null, 2);
  }catch(err){
    out.textContent = JSON.stringify(err.response?.data || {error: err.message}, null, 2);
  }
}
async function loadAudits(){
  const out = document.getElementById('auditsOut');
  const tbody = document.getElementById('auditsTbody');
  tbody.innerHTML = '';
  try{
    const res = await api.get('/api/audits/');
    out.textContent = JSON.stringify(res.data, null, 2);
    (res.data.results || res.data || []).forEach(a => {
      const tr = document.createElement('tr');
      tr.innerHTML = `<td>${a.event||''}</td>
        <td>${a.user||a.username||''}</td>
        <td>${a.created_at ? new Date(a.created_at).toLocaleString() : ''}</td>`;
      tbody.appendChild(tr);
    });
  }catch(err){
    out.textContent = JSON.stringify(err.response?.data || {error: err.message}, null, 2);
  }
}
let chartEstado, chartPeriodo;
async function loadReports(){
  const out = document.getElementById('reportsOut');
  try{
    const res = await api.get('/api/reports/generate/');
    out.textContent = JSON.stringify(res.data, null, 2);
    const porEstado = res.data?.por_estado || {};
    const porPeriodo = res.data?.por_periodo || {};
    if(chartEstado) chartEstado.destroy();
    chartEstado = new Chart(document.getElementById('chartEstado'), {
      type: 'bar',
      data: { labels: Object.keys(porEstado), datasets: [{ label: 'Por estado', data: Object.values(porEstado) }] }
    });
    if(chartPeriodo) chartPeriodo.destroy();
    chartPeriodo = new Chart(document.getElementById('chartPeriodo'), {
      type: 'bar',
      data: { labels: Object.keys(porPeriodo), datasets: [{ label: 'Por periodo', data: Object.values(porPeriodo) }] }
    });
  }catch(err){
    out.textContent = JSON.stringify(err.response?.data || {error: err.message}, null, 2);
  }
}
(function init(){ if(localStorage.getItem('token')) setStatus('Autenticado', true); })();
