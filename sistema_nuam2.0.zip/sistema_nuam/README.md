
# sistema_nuam (API Django + DRF)

API base para el proyecto NUAM con:
- Django 5 + DRF
- JWT (SimpleJWT)
- OpenAPI (drf-spectacular) en **/api/docs/**
- CORS
- Auditoría con django-simple-history
- Endpoints: auth/profile, users, ratings (carga y consultas), audits, reports

## Requisitos
- Python 3.11+
- pip

## Instalación local (SQLite por defecto)
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# Linux/Mac: source .venv/bin/activate

pip install -r requirements.txt
cp .env.example .env

python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```

## PostgreSQL (producción)
Configura variables en `.env` y descomenta el bloque en `nuam_core/settings.py`.

## Endpoints principales
- /api/auth/login/  (POST, obtiene tokens)
- /api/auth/refresh/ (POST, refresca token)
- /api/auth/profile/ (GET, perfil)
- /api/users/  (CRUD admin)
- /api/ratings/ (GET/POST) filtros: ?cliente=&periodo=&estado=
- /api/ratings/upload/ (POST) CSV: cliente,tipo,periodo,estado,fuente
- /api/audits/ (GET) historial simple
- /api/reports/generate/ (GET) agregados
- /api/docs/ (Swagger)
```
#   s i s t e m a _ n u a m  
 