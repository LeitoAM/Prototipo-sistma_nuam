# accounts/views.py
from rest_framework import generics, permissions
from rest_framework.response import Response
from rest_framework.views import APIView
from django.contrib.auth import get_user_model

from rest_framework_simplejwt.views import TokenObtainPairView
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer
from rest_framework.exceptions import ValidationError, AuthenticationFailed

from .serializers import UserSerializer, UserCreateSerializer
from .permissions import IsAdmin

User = get_user_model()

class SpanishTokenObtainPairSerializer(TokenObtainPairSerializer):
    default_error_messages = {
        "no_active_account": "Usuario o contraseña incorrecta"
    }

    def validate(self, attrs):
        username = (attrs.get("username") or "").strip()
        password = (attrs.get("password") or "").strip()
        if not username or not password:
            # HU-02: mensaje de error por campos vacíos
            raise ValidationError({"message": "Rellene los campos vacíos"})
        try:
            data = super().validate(attrs)
        except Exception:
            # HU-02: credenciales malas
            raise AuthenticationFailed(detail="Usuario o contraseña incorrecta")
        # HU-01: éxito
        data["message"] = "Acceso permitido"
        return data

class SpanishTokenObtainPairView(TokenObtainPairView):
    serializer_class = SpanishTokenObtainPairSerializer


class ProfileView(APIView):
    permission_classes = [permissions.IsAuthenticated]
    def get(self, request):
        return Response(UserSerializer(request.user).data)


class UserListCreateView(generics.ListCreateAPIView):
    queryset = User.objects.all().order_by("id")
    serializer_class = UserCreateSerializer
    permission_classes = [IsAdmin]


class UserDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = User.objects.all()
    serializer_class = UserSerializer
    permission_classes = [IsAdmin]
