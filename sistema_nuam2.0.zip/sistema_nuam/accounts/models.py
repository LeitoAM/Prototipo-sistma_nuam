
from django.contrib.auth.models import AbstractUser
from django.db import models
from simple_history.models import HistoricalRecords

class User(AbstractUser):
    class Roles(models.TextChoices):
        ADMIN = "ADMIN", "Administrador"
        ANALISTA = "ANALISTA", "Analista"
        AUDITOR = "AUDITOR", "Auditor"

    role = models.CharField(max_length=20, choices=Roles.choices, default=Roles.ANALISTA)
    history = HistoricalRecords()

    def __str__(self):
        return f"{self.username} ({self.role})"
