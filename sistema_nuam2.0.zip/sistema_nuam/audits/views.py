
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from ratings.models import TaxRating
from django.contrib.auth import get_user_model

User = get_user_model()

class AuditListView(APIView):
    permission_classes = [IsAuthenticated]
    def get(self, request):
        data = []
        for h in list(User.history.all().order_by("-history_date")[:50]):
            data.append({
                "model": "User",
                "id": h.id,
                "actor": getattr(h.history_user, "username", None),
                "date": h.history_date,
                "type": h.history_type,
            })
        for h in list(TaxRating.history.all().order_by("-history_date")[:50]):
            data.append({
                "model": "TaxRating",
                "id": h.id,
                "actor": getattr(h.history_user, "username", None),
                "date": h.history_date,
                "type": h.history_type,
                "cliente": h.cliente,
                "estado": h.estado,
            })
        data.sort(key=lambda x: x.get("date"), reverse=True)
        return Response(data[:100])
