
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from django.db.models import Count
from ratings.models import TaxRating

class GenerateReportView(APIView):
    permission_classes = [IsAuthenticated]
    def get(self, request):
        by_estado = list(TaxRating.objects.values("estado").annotate(total=Count("id")).order_by("estado"))
        by_periodo = list(TaxRating.objects.values("periodo").annotate(total=Count("id")).order_by("periodo"))
        return Response({"by_estado": by_estado, "by_periodo": by_periodo})
