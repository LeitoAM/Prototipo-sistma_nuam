
from rest_framework import serializers
from .models import TaxRating

class TaxRatingSerializer(serializers.ModelSerializer):
    class Meta:
        model = TaxRating
        fields = ["id","cliente","tipo","periodo","estado","fuente","created_at","updated_at"]
        read_only_fields = ["id","created_at","updated_at"]
