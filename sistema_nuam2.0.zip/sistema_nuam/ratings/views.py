
import csv, io, os
from rest_framework import generics, permissions, status
from rest_framework.response import Response
from rest_framework.decorators import api_view, permission_classes
from django_filters import rest_framework as filters
from .models import TaxRating
from .serializers import TaxRatingSerializer

class TaxRatingFilter(filters.FilterSet):
    cliente = filters.CharFilter(field_name="cliente", lookup_expr="icontains")
    periodo = filters.CharFilter(field_name="periodo", lookup_expr="icontains")
    estado = filters.CharFilter(field_name="estado", lookup_expr="iexact")

    class Meta:
        model = TaxRating
        fields = ["cliente","periodo","estado"]

class TaxRatingListCreate(generics.ListCreateAPIView):
    queryset = TaxRating.objects.all()
    serializer_class = TaxRatingSerializer
    filterset_class = TaxRatingFilter
    permission_classes = [permissions.IsAuthenticated]

    def list(self, request, *args, **kwargs):
        # HU-04: exigir al menos 1 filtro
        params = request.query_params
        if not any(params.get(k) for k in ["cliente", "periodo", "estado"]):
            return Response(
                {"message": "Complete al menos un campo para buscar datos"},
                status=status.HTTP_400_BAD_REQUEST
            )
        queryset = self.filter_queryset(self.get_queryset())
        page = self.paginate_queryset(queryset)
        count = queryset.count() if page is None else len(page)
        if count == 0:
            return Response({"message": "Resultados no encontrados", "count": 0, "results": []})
        serializer = self.get_serializer(page if page is not None else queryset, many=True)
        msg = f"Resultados encontrados ({count})"
        if page is not None:
            return self.get_paginated_response({"message": msg, "results": serializer.data})
        return Response({"message": msg, "count": count, "results": serializer.data})

@api_view(["POST"])
@permission_classes([permissions.IsAuthenticated])
def upload_csv(request):
    """
    Espera un archivo 'file' (CSV) con encabezados:
    cliente,tipo,periodo,estado,(fuente)
    """
    f = request.FILES.get("file")
    if not f:
        return Response({"message": "Adjunte un archivo en el campo 'file'."}, status=400)

    # HU-08: validar formato de archivo
    name = getattr(f, "name", "").lower()
    if not name.endswith(".csv"):
        return Response({"message": "Formato de archivo inválido"}, status=400)

    try:
        data = f.read().decode("utf-8")
    except UnicodeDecodeError:
        # archivo corrupto / encoding malo
        return Response({"message": "Archivo incompatible o corrupto (use UTF-8)."}, status=400)

    reader = csv.DictReader(io.StringIO(data))
    required = {"cliente","tipo","periodo","estado"}
    if not reader.fieldnames or not required.issubset(set(reader.fieldnames)):
        return Response({"message": "Encabezados requeridos: cliente,tipo,periodo,estado,(fuente)"}, status=400)

    created = 0
    errors = []
    for idx, row in enumerate(reader, start=2):
        try:
            tr = TaxRating(
                cliente=(row.get("cliente") or "").strip(),
                tipo=(row.get("tipo") or "").strip(),
                periodo=(row.get("periodo") or "").strip(),
                estado=(row.get("estado") or "").strip().upper(),
                fuente=(row.get("fuente") or "carga").strip(),
            )
            tr.full_clean()
            tr.save()
            created += 1
        except Exception as e:
            errors.append({"row": idx, "error": str(e)})

    if created > 0 and not errors:
        # HU-05/CP-03.1: “Importación exitosa”
        return Response({"message": "Importación exitosa", "created": created, "errors": []}, status=201)
    elif created > 0 and errors:
        # Mezcla: algunas filas buenas y otras malas
        return Response({"message": "Carga exitosa con observaciones", "created": created, "errors": errors}, status=207)
    else:
        return Response({"message": "No se cargaron registros válidos", "created": 0, "errors": errors}, status=400)