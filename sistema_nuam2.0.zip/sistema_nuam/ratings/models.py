from django.db import models
from simple_history.models import HistoricalRecords

class TaxRating(models.Model):

    class Estados(models.TextChoices):
        VIGENTE = "VIGENTE", "Vigente"
        OBSERVADA = "OBSERVADA", "Observada"
        RECHAZADA = "RECHAZADA", "Rechazada"

    cliente = models.CharField(
        max_length=120,
        db_index=True,
        help_text="Nombre del contribuyente o empresa."
    )
    tipo = models.CharField(
        max_length=60,
        help_text="Tipo de impuesto, por ejemplo: IVA, RENTA, etc."
    )
    periodo = models.CharField(
        max_length=20,
        db_index=True,
        help_text="Periodo tributario en formato AAAA-MM. Ej: 2025-10."
    )
    estado = models.CharField(
        max_length=20,
        choices=Estados.choices,
        db_index=True,
        help_text="Estado de la calificación tributaria."
    )
    fuente = models.CharField(
        max_length=60,
        blank=True,
        default="carga",
        help_text="Fuente de la información. Ej: SII, Interno, etc."
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    history = HistoricalRecords()

    class Meta:
        ordering = ["-created_at"]
        verbose_name = "Calificación Tributaria"
        verbose_name_plural = "Calificaciones Tributarias"

    def __str__(self):
        return f"{self.cliente} - {self.tipo} ({self.estado})"