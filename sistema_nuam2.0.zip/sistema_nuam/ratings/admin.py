from django.contrib import admin
from .models import TaxRating
admin.site.register(TaxRating)
