
from django.urls import path
from .views import TaxRatingListCreate, upload_csv

urlpatterns = [
    path("", TaxRatingListCreate.as_view(), name="ratings-list-create"),
    path("upload/", upload_csv, name="ratings-upload"),
]
