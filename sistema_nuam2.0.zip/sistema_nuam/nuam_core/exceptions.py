# nuam_core/exceptions.py
from rest_framework.views import exception_handler

def custom_exception_handler(exc, context):
    response = exception_handler(exc, context)
    if response and isinstance(response.data, dict):
        # si ya trae "message", no toco
        if "message" not in response.data:
            # compactar errores comunes en un solo "message"
            msg = response.data.get("detail") or str(response.data)
            response.data = {"message": msg}
    return response
